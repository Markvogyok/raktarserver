const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = 4000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const file = 'adatok.json';

if (!fs.existsSync(file)) {
  fs.writeFileSync(file, JSON.stringify([]));
}

function betoltadatok() {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function mentadatok(adatok) {
  fs.writeFileSync(file, JSON.stringify(adatok, null, 2));
}

app.get('/api/termekek', (req, res) => {
  res.json(betoltadatok());
});

app.post('/api/termekek', (req, res) => {
  const { nev, tipus, mennyiseg } = req.body;

  if (!nev || !tipus || !mennyiseg) {
    return res.status(400).json({ error: 'Minden mező kitöltése kötelező!' });
  }

  const adatok = betoltadatok();
  const uj = { id: Date.now(), nev, tipus, mennyiseg: parseFloat(mennyiseg) };
  adatok.push(uj);
  mentadatok(adatok);

  res.json({ message: 'Termék hozzáadva', uj });
});

app.put('/api/termekek/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { nev, tipus, mennyiseg } = req.body;

  let adatok = betoltadatok();
  const index = adatok.findIndex(t => t.id === id);

  if (index === -1) return res.status(404).json({ error: 'Nincs ilyen termék' });

  adatok[index] = { ...adatok[index], nev, tipus, mennyiseg: parseFloat(mennyiseg) };
  mentadatok(adatok);

  res.json({ message: 'Termék módosítva', uj: adatok[index] });
});

app.delete('/api/termekek/:id', (req, res) => {
  const id = parseInt(req.params.id);
  let adatok = betoltadatok();

  adatok = adatok.filter(t => t.id !== id);
  mentadatok(adatok);

  res.json({ message: 'Termék törölve' });
});

app.listen(PORT, () => {
  console.log(`Szerver fut: http://localhost:${PORT}`);
});